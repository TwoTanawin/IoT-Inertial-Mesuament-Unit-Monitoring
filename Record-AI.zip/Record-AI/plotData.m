fileName = DAY01;
data = xlsread(fileName);